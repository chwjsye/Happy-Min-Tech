﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class Brackets
    {
        //public static string[] calculation = new string[] { "＋", "－", "×", "÷" };
        //public static List<int> Generate(string exe,int operators)
        //{
        //    List<int> opcount=null;
        //    int l = 0;
        //    for (int i = 0; i < exe.Length; i++)
        //    {
        //        string opstr = exe[i].ToString();
        //        if (opstr == "＋" || opstr == "－" || opstr == "×" || opstr == "÷")
        //        {
        //            opcount.Add(i) ;
        //            l++;
        //        }
        //    }
        //    GenerateOP(exe,opcount);
        //    return opcount;
        //}
        //public static string GenerateOP(string exe, List<int> opcount)
        //{
        //    foreach (int i in opcount)
        //    {
        //        if (exe[i].ToString() == "+" || exe[i].ToString() == "-")
        //        {

        //        }
        //    }
        //}
    }
}
